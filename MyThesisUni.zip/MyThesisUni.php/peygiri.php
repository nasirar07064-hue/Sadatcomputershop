<?php include('includes/header.php'); ?>
    
		<!-- WRAPPER -->
		<div id="wrapper">
			

		<!-- MAIN -->
		<div id="main" >
			
			<!-- content -->
			<div id="content" >
				
				<!-- title -->
				<div id="page-title">
					<span class="title"></span>
					<span class="subtitle"></span>
				</div>
				<!-- ENDS title -->
				<h1 class="contenth1">پیگیری خرید</h1>
				<!-- Portfolio -->
<?php     
      if(isset($_GET['namee']))
	  {
		  ?>
<table width="100%">
 <tr id="main_column_tr" > <td>ردیف</td><td>کد </td><td>نام</td><td>ایمیل</td><td>تلفن</td><td>آدرس</td><td>محصول</td><td>مبلغ</td><td>تاریخ</td><td>ساعت</td>          <td>نتیجه</td></tr>
          <?php
		  $dbresult = mysqli_query(Connect(),"select * from transactions where u_name='".$_GET['namee']."' and u_email='".$_GET['email']."' order by id desc ");
		  $rowstyle=0;
				$radif=0;
				while($post = mysqli_fetch_assoc ($dbresult) )
				{
					$radif++;
				
					$mahsul='';
					$result_t='';
						$dbresult2 = mysqli_query(Connect(),"select titr from mtbldownload where id=".$post['down_id']);
						$post2 = mysqli_fetch_assoc ($dbresult2);
						$mahsul=$post2['titr'];						
				
					if($post['result']==0)
					$result_t='<span style="color:red">ناموفق</span>';
					else if($post['result']==1)
					$result_t='<span style="color:green">موفق</span>';
					echo('
					<tr >
					  <td>'.$radif.'</td>
					  <td>'.$post['id'].'</td>
					  <td>'.$post['u_name'].'</td>
					  <td>'.$post['u_email'].'</td>
					  <td>'.$post['u_tell'].'</td>
					  <td>'.$post['u_address'].'</td>
					  <td>'.$mahsul.'</td>
					  <td style=" font-weight:bold;color:green;">'.$post['price'].'</td>
					  <td>'.$post['date'].'</td>
					  <td>'.$post['time'].'</td>
					  <td>'.$result_t.'</td>
	
					</tr>');
				}
      }
?>
</table>
<hr>
<form method="get">
 <input type="text" name="namee" class="side_serach" placeholder="نام شما"  /><br>
<input type="text" name="email" class="side_serach" placeholder="ایمیل شما"  />
<input type="submit" name="submit" style="text-align:center" class="side_serach" value="مشاهده لیست سفارشات"  />
</form>


			</div>
			<!-- ENDS content -->
            
            <!-- start sidebar -->
<?php include('includes/sidebar.php'); ?>

			
		
			<!-- FOOTER -->
	<?php include('includes/footer.php'); ?>