گزارش اشکالات و اصلاحات پروژه (ThesisUni / فروشگاه کامپیوتری)
==============================================================

دیتابیس: computershop  (فایل computershop.sql را import کنید)
کاربر مدیر: username = admin  /  password = 123456  (جدول mtbluser)
ورود مدیر از طریق فرم ورود در سایدبار صفحه اصلی انجام می‌شود.

--------------------------------------------------------------
مشکلاتی که پیدا و اصلاح شد:
--------------------------------------------------------------

1) استفاده از توابع قدیمی mysql_* که در PHP 7 و بالاتر حذف شده‌اند
   و باعث خطای Fatal Error می‌شدند.
   فایل‌ها: manage/includes/bankselect.php ، manage/mep.php ،
   login/loginchek2.php ، login/manage_remember.php ، login/index.php
   -> همه به mysqli_* تبدیل شدند.

2) نام اشتباه دیتابیس در bankselect.php
   قبلاً به دیتابیس "sourcecode" وصل می‌شد، در حالی که دیتابیس
   واقعی پروژه "computershop" است. -> اصلاح شد.

3) ترتیب اشتباه آرگومان‌های mysqli_query
   در login/index.php به صورت mysqli_query("...", $dlink) نوشته شده بود؛
   در mysqli ترتیب صحیح mysqli_query($dlink, "...") است. -> اصلاح شد.

4) مسیر اشتباه include برای bankselect.php
   در login/index.php و login/manage_remember.php مسیر '../includes/bankselect.php'
   بود که وجود ندارد؛ فایل واقعی در '../manage/includes/bankselect.php' است.
   -> اصلاح شد.

5) include اشتباه در saveuser.php و savecontact.php
   این دو فایل 'includes/bankselect.php' را include می‌کردند (مسیر ناموجود)
   و در نتیجه توابع Connect() و clean() تعریف نمی‌شدند و ثبت‌نام/پیام
   کار نمی‌کرد. -> به require_once('includes/config.php') تغییر یافت.

6) سمی‌کولن اضافی در savecontact.php
   دستور if (isset($_POST['name'])); با سمی‌کولن اضافی بلااثر شده بود.
   -> اصلاح شد.

7) ناهماهنگی کلیدهای Session در ورود مدیر
   login/loginchek2.php کلید $_SESSION['Logedin'] را تنظیم می‌کرد، اما صفحات
   پنل مدیریت (manage/*) کلید $_SESSION['usernam']=='admin' را چک می‌کنند؛
   در نتیجه ورود از این مسیر به پنل راه نمی‌داد.
   -> $_SESSION['usernam']='admin' نیز اضافه شد.

8) ریدایرکت به فایل ناموجود
   پس از ورود، کاربر به manage/manage.php هدایت می‌شد که وجود ندارد؛
   فایل صحیح manage/index.php است. -> اصلاح شد.

--------------------------------------------------------------
مواردی که باید بدانید (خارج از محدوده اجرا شدن):
--------------------------------------------------------------

- امنیت (SQL Injection): تقریباً همه کوئری‌ها ورودی کاربر را مستقیماً داخل
  رشتهٔ SQL قرار می‌دهند. برای یک پروژهٔ واقعی باید از Prepared Statements
  استفاده شود.
- رمزهای عبور به صورت متن ساده ذخیره شده‌اند (باید password_hash شوند).
- برخی صفحات پنل (مانند mep.php و me_movie.php) به جدول‌های mtblpost و mtblmovie
  اشاره می‌کنند که در فایل computershop.sql وجود ندارند (دادهٔ واقعی در
  mtbldownload و mtblaudio است). این صفحات ماژول‌های قدیمی/بلااستفاده
  هستند؛ در صورت نیاز باید جدول مربوطه ساخته شود.
