<?php
session_start();
function send($url,$api,$amount,$redirect){
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_POSTFIELDS,"api=$api&amount=$amount&redirect=$redirect");
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
$res = curl_exec($ch);
curl_close($ch);
return $res;
}

if($_GET['type']==2)
{
	
include_once('jdf.php');
$shamsidate=jdate('Y/m/d');
$shamsitime=jdate('H:i:s');	
include('includes/function.php');  
$sql = "INSERT INTO  `transactions` (
`id` ,
`down_id` ,
`price` ,
`type`,
`date` ,
`time`,
`ip` 
)
VALUES (
NULL ,  ".$_GET['post_id'].",".$_GET['amount'].",2,  '".$shamsidate."',  '".$shamsitime."',  '".$_SERVER['REMOTE_ADDR']."');";
// echo $sql;
 mysqli_query(Connect(),$sql);	
 
 	  $dbresult = mysqli_query(Connect(),"select max(id) as mx  from `transactions` ");
	  $t_id = mysqli_fetch_assoc($dbresult);
//echo $t_id['mx'];


 $result = send('http://payline.ir/payment/gateway-send','fc0c9-dfed0-b21e7-426f2-397df094041d7c46ad70972036f8'
,$_GET['amount']*10,urlencode('http://www.toyoshop.ir/reciever.php?t_id='.$t_id['mx']));
} 
if($result > 0 && is_numeric($result))
{  
$sql = "UPDATE  `transactions` SET  
`id_get` =  ".$result." 
 WHERE  id =".$t_id['mx'].";";
  mysqli_query(Connect(),$sql);
$go = "http://payline.ir/payment/gateway-$result";
header("Location: $go");
}
switch($result){
case '-1':
echo 'sazgar nist';
break;
case '-2':
echo 'kamtar az 1000 ast';
break;
case '-3':
echo 'redirect null ast';
break;
case '-4':
echo 'dargah yaft nashod';
break;
}





?>