-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 13, 2026 at 10:51 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `computershop`
--

-- --------------------------------------------------------

--
-- Table structure for table `mtbladvertise`
--

CREATE TABLE `mtbladvertise` (
  `id` int(10) UNSIGNED NOT NULL,
  `titr` text COLLATE utf8_persian_ci NOT NULL,
  `image` text COLLATE utf8_persian_ci NOT NULL,
  `link` text COLLATE utf8_persian_ci NOT NULL,
  `enabled` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `mtbladvertise`
--

INSERT INTO `mtbladvertise` (`id`, `titr`, `image`, `link`, `enabled`) VALUES
(1, 'تبلیغ 1', 'images/advertise/1332504231ads-WWW.BALYAN-39.gif', '', 1),
(2, 'تبلیغ 2', 'images/advertise/1122.gif', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mtblaudio`
--

CREATE TABLE `mtblaudio` (
  `id` int(11) NOT NULL,
  `titr` text COLLATE utf8_persian_ci NOT NULL,
  `shorttext` text COLLATE utf8_persian_ci NOT NULL,
  `longtext` text COLLATE utf8_persian_ci NOT NULL,
  `image` text COLLATE utf8_persian_ci NOT NULL,
  `type` int(11) NOT NULL,
  `subjectid` int(11) NOT NULL,
  `writerid` int(11) NOT NULL,
  `writedate` text COLLATE utf8_persian_ci NOT NULL,
  `writetime` text COLLATE utf8_persian_ci NOT NULL,
  `like` int(11) NOT NULL,
  `view` int(11) NOT NULL,
  `star` int(11) NOT NULL,
  `published` tinyint(4) NOT NULL,
  `keywords` text COLLATE utf8_persian_ci NOT NULL,
  `description` text COLLATE utf8_persian_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `mtblaudio`
--

INSERT INTO `mtblaudio` (`id`, `titr`, `shorttext`, `longtext`, `image`, `type`, `subjectid`, `writerid`, `writedate`, `writetime`, `like`, `view`, `star`, `published`, `keywords`, `description`) VALUES
(73, 'خبر اصلی', '', '', 'images/post/2Software-Gerdoo-Pack-No-215dfa70.jpg', 1, 0, 1, '۱۳۹۴/۰۲/۰۸', '۱۶:۳۴:۵۷', 0, 0, 0, 1, '', ''),
(74, 'دانلود سورس پروژه پایانی ', '', '', 'images/post/2ed380ac6-4f8f-4363-b853-ada961f17d0a.jpg', 1, 0, 1, '۱۳۹۴/۰۲/۰۸', '۱۶:۳۵:۰۹', 0, 1, 0, 1, '', ''),
(75, 'مانیتور ال جی زیبا', '', '', 'images/post/2select_monitor.jpg', 1, 0, 1, '۱۴۰۰/۰۳/۱۲', '۱۶:۵۴:۴۱', 0, 1, 0, 0, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `mtblcomment`
--

CREATE TABLE `mtblcomment` (
  `id` int(11) NOT NULL,
  `postid` int(11) NOT NULL,
  `name` text COLLATE utf8_persian_ci NOT NULL,
  `email` text COLLATE utf8_persian_ci NOT NULL,
  `comment` text COLLATE utf8_persian_ci NOT NULL,
  `date_time` text COLLATE utf8_persian_ci NOT NULL,
  `pagename` text COLLATE utf8_persian_ci NOT NULL,
  `readed` tinyint(4) NOT NULL DEFAULT '0',
  `ip` text COLLATE utf8_persian_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtbldownload`
--

CREATE TABLE `mtbldownload` (
  `id` int(11) NOT NULL,
  `name` text COLLATE utf8_persian_ci NOT NULL,
  `titr` text COLLATE utf8_persian_ci NOT NULL,
  `shorttext` text COLLATE utf8_persian_ci NOT NULL,
  `longtext` text COLLATE utf8_persian_ci NOT NULL,
  `image` text COLLATE utf8_persian_ci NOT NULL,
  `type` int(11) NOT NULL,
  `subjectid` int(11) NOT NULL,
  `writerid` int(11) NOT NULL,
  `writedate` text COLLATE utf8_persian_ci NOT NULL,
  `writetime` text COLLATE utf8_persian_ci NOT NULL,
  `publisheddate` text COLLATE utf8_persian_ci NOT NULL,
  `publishedtime` text COLLATE utf8_persian_ci NOT NULL,
  `expirationdate` text COLLATE utf8_persian_ci NOT NULL,
  `expirationtime` text COLLATE utf8_persian_ci NOT NULL,
  `like` int(11) NOT NULL,
  `view` int(11) NOT NULL,
  `star` int(11) NOT NULL,
  `link1` text COLLATE utf8_persian_ci NOT NULL,
  `linktitle1` text COLLATE utf8_persian_ci NOT NULL,
  `linkpass1` text COLLATE utf8_persian_ci NOT NULL,
  `link2` text COLLATE utf8_persian_ci NOT NULL,
  `linktitle2` text COLLATE utf8_persian_ci NOT NULL,
  `linkpass2` text COLLATE utf8_persian_ci NOT NULL,
  `link3` text COLLATE utf8_persian_ci NOT NULL,
  `linktitle3` text COLLATE utf8_persian_ci NOT NULL,
  `linkpass3` text COLLATE utf8_persian_ci NOT NULL,
  `published` tinyint(4) NOT NULL,
  `price` bigint(20) NOT NULL DEFAULT '0',
  `keywords` text COLLATE utf8_persian_ci NOT NULL,
  `description` text COLLATE utf8_persian_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `mtbldownload`
--

INSERT INTO `mtbldownload` (`id`, `name`, `titr`, `shorttext`, `longtext`, `image`, `type`, `subjectid`, `writerid`, `writedate`, `writetime`, `publisheddate`, `publishedtime`, `expirationdate`, `expirationtime`, `like`, `view`, `star`, `link1`, `linktitle1`, `linkpass1`, `link2`, `linktitle2`, `linkpass2`, `link3`, `linktitle3`, `linkpass3`, `published`, `price`, `keywords`, `description`) VALUES
(137, '', 'ماوس درجه یک', 'خلاصه مطلب', '', 'images/post/10.973168001285794523_irannaz_com.jpg', 1, 90, 1, '1402/04/21', '۱۶:۲۱:۲۷', '', '', '', '', 0, 2, 0, '', '', '', '', '', '', '', '', '', 1, 5000, '', ''),
(138, '', 'ماوس درجه یک دوم', 'خلاصه مطلب', '', 'images/post/1images (2).jpg', 1, 90, 1, '1402/04/21', '۱۶:۳۱:۴۲', '', '', '', '', 0, 2, 0, '', '', '', '', '', '', '', '', '', 1, 5000, '', ''),
(139, '', 'کیبورد درجه یک دوم', 'خلاصه مطلب', '', 'images/post/19ef080472e42462.jpg', 1, 89, 1, '1402/04/21', '۱۶:۲۶:۰۰', '', '', '', '', 0, 1, 0, '', '', '', '', '', '', '', '', '', 1, 16500, '', ''),
(140, 'vizhe', 'کیبورد درجه یک', 'خلاصه مطلب', '', 'images/post/11350078347-keyboard1.jpg', 1, 89, 1, '1402/04/21', '۱۶:۲۵:۴۸', '', '', '', '', 0, 0, 0, '', '', '', '', '', '', '', '', '', 1, 18000, '', ''),
(141, '', 'کیس زیبای مشکی', '', '', 'images/post/1x13.jpg', 1, 88, 1, '1402/04/21', '۱۶:۲۵:۳۶', '', '', '', '', 0, 7, 0, '', '', '', '', '', '', '', '', '', 1, 65000, '', ''),
(142, 'vizhe', 'کیس زیبای مشکی دوم', '', '', 'images/post/124903_1512981604_tn_ALIENWARE AURA.jpg', 1, 87, 1, '1402/04/21', '۱۶:۳۱:۵۴', '', '', '', '', 0, 0, 0, '', '', '', '', '', '', '', '', '', 1, 0, '', ''),
(143, '', 'کیس زیبای مشکی سوم', '', '', 'images/post/111657-2.jpg', 1, 87, 1, '1402/04/21', '۱۶:۲۶:۲۷', '', '', '', '', 0, 1, 0, '', '', '', '', '', '', '', '', '', 1, 0, '', ''),
(144, '', 'مانیتور ال جی زیبا ', '', '', 'images/post/1ed380ac6-4f8f-4363-b853-ada961f17d0a.jpg', 1, 91, 1, '1402/04/21', '۱۶:۲۹:۳۲', '', '', '', '', 0, 0, 0, '', '', '', '', '', '', '', '', '', 1, 0, '', ''),
(145, '', 'مانیتور ال جی زیبا ', '', '', 'images/post/1Monitor_M2794D_BigImage.gif', 1, 91, 1, '1402/04/21', '۱۶:۲۹:۴۱', '', '', '', '', 0, 2, 0, '', '', '', '', '', '', '', '', '', 1, 0, '', ''),
(146, '', 'مانیتور ال جی زیبا ', '', '', 'images/post/1select_monitor.jpg', 1, 91, 1, '1402/04/21', '۱۶:۲۹:۴۹', '', '', '', '', 0, 9, 0, '', '', '', '', '', '', '', '', '', 1, 0, '', ''),
(147, '', 'مجموعه نرم افزار زبان اصلی', '', '', 'images/post/1sponge-software-product-pack.png', 1, 92, 1, '1402/04/21', '۱۶:۳۱:۰۷', '', '', '', '', 0, 2, 0, '', '', '', '', '', '', '', '', '', 0, 80000, '', ''),
(148, '', 'مجموعه نرم افزار گردو', '', '', 'images/post/1Software-Gerdoo-Pack-No-215dfa70.jpg', 1, 92, 1, '1402/04/21', '۱۰:۵۵:۲۴', '', '', '', '', 0, 39, 0, 'filedownloads/1Handle_Commitment (1).pdf', 'دانلود با لینک مستقیم', '', '', '', '', '', '', '', 1, 1000, '', ''),
(152, '', '1', '1', '<p>1111</p>\r\n', 'images/post/1delivery ffff.jpg', 1, 87, 1, '۱۴۰۲/۰۵/۲۶', '۱۷:۵۳:۰۱', '', '', '', '', 0, 0, 0, 'filedownloads/1about.jpg', '', '', '', '', '', '', '', '', 1, 0, '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `mtblip`
--

CREATE TABLE `mtblip` (
  `id` int(11) NOT NULL,
  `ip` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `date` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mtblmenu`
--

CREATE TABLE `mtblmenu` (
  `id` int(11) NOT NULL,
  `title` text COLLATE utf8_persian_ci NOT NULL,
  `link` text COLLATE utf8_persian_ci NOT NULL,
  `enabled` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `mtblmenu`
--

INSERT INTO `mtblmenu` (`id`, `title`, `link`, `enabled`) VALUES
(2, 'مقالات', '', 1),
(3, 'کالاها', '', 1),
(4, 'ویدیو ها', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mtblmessage`
--

CREATE TABLE `mtblmessage` (
  `ID` bigint(10) UNSIGNED NOT NULL,
  `Sender` int(11) NOT NULL,
  `Reciver` int(11) NOT NULL,
  `Title` text COLLATE utf8_persian_ci NOT NULL,
  `Text` mediumtext COLLATE utf8_persian_ci NOT NULL,
  `SendDate` text COLLATE utf8_persian_ci NOT NULL,
  `SendTime` text COLLATE utf8_persian_ci NOT NULL,
  `Readed` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtblslider`
--

CREATE TABLE `mtblslider` (
  `id` int(11) NOT NULL,
  `titr` text COLLATE utf8_persian_ci NOT NULL,
  `shorttext` text COLLATE utf8_persian_ci NOT NULL,
  `image` text COLLATE utf8_persian_ci NOT NULL,
  `link` text COLLATE utf8_persian_ci NOT NULL,
  `enabled` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `mtblslider`
--

INSERT INTO `mtblslider` (`id`, `titr`, `shorttext`, `image`, `link`, `enabled`) VALUES
(19, 'تیتر 44', '1', 'images/slider/12.jpg', '', 1),
(18, 'slider1', '', 'images/slider/11.jpg', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mtblsubmenu`
--

CREATE TABLE `mtblsubmenu` (
  `id` int(11) NOT NULL,
  `parentid` int(11) NOT NULL,
  `title` text COLLATE utf8_persian_ci NOT NULL,
  `link` text COLLATE utf8_persian_ci NOT NULL,
  `keywords` text COLLATE utf8_persian_ci NOT NULL,
  `description` text COLLATE utf8_persian_ci NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `mtblsubmenu`
--

INSERT INTO `mtblsubmenu` (`id`, `parentid`, `title`, `link`, `keywords`, `description`, `parent`) VALUES
(87, 3, 'نرم افزار', '', '', '', 0),
(86, 3, 'سخت افزار', '', '', '', 0),
(88, 3, 'کیس', '', '', '', 86),
(89, 3, 'کیبورد', '', '', '', 86),
(90, 3, 'ماوس', '', '', '', 86),
(91, 3, 'مانیتور', '', '', '', 86),
(92, 3, 'نرم افزار عمومی', '', '', '', 87),
(93, 3, 'نرم افزار تخصصی', '', '', '', 87),
(94, 3, 'بازی', '', '', '', 87);

-- --------------------------------------------------------

--
-- Table structure for table `mtbluser`
--

CREATE TABLE `mtbluser` (
  `id` int(11) NOT NULL,
  `name` text COLLATE utf8_persian_ci NOT NULL,
  `username` text COLLATE utf8_persian_ci NOT NULL,
  `password` text COLLATE utf8_persian_ci NOT NULL,
  `city` text COLLATE utf8_persian_ci NOT NULL,
  `address` text COLLATE utf8_persian_ci NOT NULL,
  `tel` text COLLATE utf8_persian_ci NOT NULL,
  `mobil` text COLLATE utf8_persian_ci NOT NULL,
  `type` text COLLATE utf8_persian_ci NOT NULL,
  `confirm` tinyint(4) NOT NULL DEFAULT '0',
  `enabled` tinyint(4) NOT NULL DEFAULT '0',
  `mail` text COLLATE utf8_persian_ci NOT NULL,
  `ad_code` text COLLATE utf8_persian_ci NOT NULL,
  `sh_hesab` text COLLATE utf8_persian_ci NOT NULL,
  `price` double NOT NULL DEFAULT '0',
  `start_date` text COLLATE utf8_persian_ci NOT NULL,
  `almasi_date` text COLLATE utf8_persian_ci NOT NULL,
  `moaref` text COLLATE utf8_persian_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `mtbluser`
--

INSERT INTO `mtbluser` (`id`, `name`, `username`, `password`, `city`, `address`, `tel`, `mobil`, `type`, `confirm`, `enabled`, `mail`, `ad_code`, `sh_hesab`, `price`, `start_date`, `almasi_date`, `moaref`) VALUES
(1, 'محمد ناصر آرمان ', 'admin', '123456', '', '', '', '0706421035', '1', 1, 1, 'nasirarman091@gmail.com', '', '', 0, '1402/04/10', '', ''),
(2, 'علی دایی', 'ali', '123', '', '', '', '', '', 1, 1, 'ali@gmail.com', '', '', 0, '1402/04/15', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `sbtblstores`
--

CREATE TABLE `sbtblstores` (
  `ID` int(11) NOT NULL,
  `Title` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `Enabled` int(11) NOT NULL,
  `UserName` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `Password` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `ManagerName` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `ManagerMail` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `Tel` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `Mobile1` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `LastUpdate` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `Logo` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `Status` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `Address` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `VisitEnabled` int(11) NOT NULL,
  `Tags` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `WebAddress` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `AboutUs` longtext CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `daramad` longtext CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `almasi` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_persian_ci NOT NULL,
  `bardasht` longtext CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `charge` longtext CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `price_almasi` bigint(20) NOT NULL DEFAULT '0',
  `price_first` bigint(20) NOT NULL DEFAULT '0',
  `ContactUs` longtext CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sbtblstores`
--

INSERT INTO `sbtblstores` (`ID`, `Title`, `Enabled`, `UserName`, `Password`, `ManagerName`, `ManagerMail`, `Tel`, `Mobile1`, `LastUpdate`, `Logo`, `Status`, `Address`, `VisitEnabled`, `Tags`, `WebAddress`, `AboutUs`, `daramad`, `almasi`, `bardasht`, `charge`, `price_almasi`, `price_first`, `ContactUs`, `description`) VALUES
(1, 'فروشگاه کامپیوتری آرمان', 1, 'admin', 'admin', '', 'info@arman.ir', '', '', '', 'images/logo/11templatemo_logo.png', '', '', 1, 'کلمات کلیدی', 'http://www.arman.com', '<p>sdfsdfsdfserw</p>\r\n', '', '', '', '', 0, 0, '<p style="text-align:center"><span style="color:#006400"><span style="font-family:tahoma,geneva,sans-serif"><span style="font-size:14px">شما می توانید از طریق این فرم با ما در تماس باشید</span></span></span></p>\r\n', 'توضیحات چند جمله ای در مورد سایت');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` bigint(20) NOT NULL,
  `id_get` bigint(20) NOT NULL,
  `trans_id` bigint(20) NOT NULL,
  `userid` bigint(20) NOT NULL,
  `price` bigint(20) NOT NULL DEFAULT '0',
  `type` tinyint(4) NOT NULL DEFAULT '0',
  `date` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `time` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `result` tinyint(4) NOT NULL DEFAULT '0',
  `down_id` bigint(20) NOT NULL DEFAULT '0',
  `ip` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `view` int(11) NOT NULL DEFAULT '0',
  `u_name` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `u_email` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `u_tell` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `u_address` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `id_get`, `trans_id`, `userid`, `price`, `type`, `date`, `time`, `result`, `down_id`, `ip`, `view`, `u_name`, `u_email`, `u_tell`, `u_address`) VALUES
(554, 0, 0, 0, 5000, 2, '1402/04/30', '۱۶:۱۱:۲۹', 0, 562, '127.0.0.1', 0, '', '', '', ''),
(576, 0, 0, 0, 122, 2, '۱۴۰۲/۰۵/۲۴', '۲۰:۲۳:۲۱', 0, 151, '127.0.0.1', 0, 'امیرحسین برنون', 'a@a.com', '123', 'ایران');

-- --------------------------------------------------------

--
-- Table structure for table `viewsite`
--

CREATE TABLE `viewsite` (
  `ID` int(10) UNSIGNED NOT NULL,
  `All` bigint(20) NOT NULL,
  `Day` int(11) NOT NULL,
  `LastDay` int(11) NOT NULL,
  `LastDate` text COLLATE utf8_persian_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `viewsite`
--

INSERT INTO `viewsite` (`ID`, `All`, `Day`, `LastDay`, `LastDate`) VALUES
(0, 2192, 2, 2, '۱۴۰۵/۰۷/۱۹');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mtbladvertise`
--
ALTER TABLE `mtbladvertise`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mtblaudio`
--
ALTER TABLE `mtblaudio`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mtblcomment`
--
ALTER TABLE `mtblcomment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mtbldownload`
--
ALTER TABLE `mtbldownload`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mtblip`
--
ALTER TABLE `mtblip`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mtblmenu`
--
ALTER TABLE `mtblmenu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mtblmessage`
--
ALTER TABLE `mtblmessage`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `mtblslider`
--
ALTER TABLE `mtblslider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mtblsubmenu`
--
ALTER TABLE `mtblsubmenu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mtbluser`
--
ALTER TABLE `mtbluser`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sbtblstores`
--
ALTER TABLE `sbtblstores`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `viewsite`
--
ALTER TABLE `viewsite`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mtbladvertise`
--
ALTER TABLE `mtbladvertise`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `mtblaudio`
--
ALTER TABLE `mtblaudio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;
--
-- AUTO_INCREMENT for table `mtblcomment`
--
ALTER TABLE `mtblcomment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mtbldownload`
--
ALTER TABLE `mtbldownload`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=153;
--
-- AUTO_INCREMENT for table `mtblip`
--
ALTER TABLE `mtblip`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `mtblmessage`
--
ALTER TABLE `mtblmessage`
  MODIFY `ID` bigint(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mtblslider`
--
ALTER TABLE `mtblslider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `mtblsubmenu`
--
ALTER TABLE `mtblsubmenu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
--
-- AUTO_INCREMENT for table `mtbluser`
--
ALTER TABLE `mtbluser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=577;
--
-- AUTO_INCREMENT for table `viewsite`
--
ALTER TABLE `viewsite`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
