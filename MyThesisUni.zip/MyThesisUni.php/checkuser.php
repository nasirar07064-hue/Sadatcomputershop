<?php
session_start();

echo '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />';

if(isset($_POST["username"]))
   $username=$_POST["username"];
  else
   $username="0";
   
if(isset($_POST["password"]))
   $password=$_POST["password"];
  else
   $password="0";

if($username!="0"  && $password!="0")
   {
	  //include('includes/bankselect.php');
	  require_once('includes/config.php');
	   		$dbresult = mysqli_query (Connect(),"SELECT * FROM mtbluser where username='".$username."' and password='".$password."' ");  			
	          $count = mysqli_num_rows($dbresult);
			  $result=mysqli_fetch_assoc($dbresult);
			  
     if($count>0)
	 {
		  $_SESSION['userlogin'] =1;
		  $_SESSION['usernam'] =$result['username'];
		  $_SESSION['name'] =$result['name'];
	?>	
   <script type="text/javascript" >
  window.location='index.php';
  </script>
  <?php
	 }
	 else
	 {
			?>	
   <script type="text/javascript" >
  window.location='index.php?loginmsg=رمز عبور یا نام کاربری اشتباه است';
  </script>
  <?php	 
	 }
   }
else
	 {
			?>	
   <script type="text/javascript" >
  window.location='index.php?loginmsg=شما باید لاگین کنید!';
  </script>
  <?php	 
	 }

?>