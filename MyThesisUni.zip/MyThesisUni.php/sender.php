<?php
session_start();
function send($url,$api,$amount,$redirect){
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_POSTFIELDS,"api=$api&amount=$amount&redirect=$redirect");
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
$res = curl_exec($ch);
curl_close($ch);
return $res;
}

if($_POST['type']==2)
{
$namee="";$email="";$tell="";$address="";$price=0;
include('includes/config.php'); 
$namee =clean( $_POST['u_name']);
$email =clean( $_POST['u_email']);
$tell =clean( $_POST['u_tell']);
$address =clean( $_POST['u_address']);
$price =$_POST['amount'];
include_once('jdf.php');
include('includes/function.php');  
$shamsidate=jdate('Y/m/d');
$shamsitime=jdate('H:i:s');	

$sql = "INSERT INTO  `transactions` (
`id` ,
`down_id` ,
`price` ,
`type`,
`date` ,
`time`,
`ip`,
`u_name`,
`u_email`,
`u_tell`,
`u_address`

)
VALUES (
NULL ,  ".$_POST['post_id'].",".$price.",2,'".$shamsidate."',  '".$shamsitime."',
  '".$_SERVER['REMOTE_ADDR']."','".$namee."','".$email."','".$tell."','".$address."');";
 //echo $sql;
 mysqli_query(Connect(),$sql);	
 
 	  $dbresult = mysqli_query(Connect(),"select max(id) as mx  from `transactions` ");
	  $t_id = mysqli_fetch_assoc($dbresult);
//echo $t_id['mx'];


 $result = send('http://zarinpal.com','3c71f-8c25d4-d0e63-21740-8ec94bbf14ea2a3563331e81c47fc'
,$price*10,urlencode('http://www.website.ir/reciever.php?t_id='.$t_id['mx']));
//echo '<br>'.$result;
} 
header("Location: http://zarinpal.com");
/*
if($result > 0 && is_numeric($result))
{  
$sql = "UPDATE  `transactions` SET  
`id_get` =  ".$result." 
 WHERE  id =".$t_id['mx'].";";
 // mysqli_query(Connect(),$sql);
//$go = "http://payline.ir/payment/gateway-$result";
//header("Location: $go");
}
/*
switch($result){
case '-1':
echo 'sazgar nist';
break;
case '-2':
echo 'kamtar az 1000 ast';
break;
case '-3':
echo 'redirect null ast';
break;
case '-4':
echo 'dargah yaft nashod';
break;
}
*/




?>