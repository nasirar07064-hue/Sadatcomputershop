<?php
// Fixed: migrated from the deprecated mysql_* API to mysqli and
// corrected the database name (was 'sourcecode', the real DB is 'computershop').
$dlink = mysqli_connect("localhost", "root", "", "computershop");
if ($dlink) {
    mysqli_set_charset($dlink, "utf8");
    mysqli_query($dlink, "SET SESSION collation_connection = 'utf8_persian_ci'");
}
?>