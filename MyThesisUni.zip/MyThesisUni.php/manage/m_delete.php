<?php 
session_start();
  if($_SESSION['usernam']!='admin'){
	  header('location:../index.php?notlogin');
	  exit();
  }
		  else
		  {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>



<body>
<?php
$post_id=$_GET['id'];
$typeback=$_GET['type_back'];
if(is_numeric($post_id)   && is_numeric($typeback))
{
              include('includes/function.php');
			  
	if($typeback ==1)
	{  
	 //delete old logo from directory
	  $dbresult= mysqli_query(Connect(),"select `image` from `mtblpost` where id=".$post_id);
	  $filename_delete=mysqli_fetch_assoc($dbresult);
	  @unlink('../'.$filename_delete['image']);
				  mysqli_query(Connect(),"delete from  mtblpost  WHERE  id =".$post_id);
	}
	else if($typeback ==2)
	{  
		//delete old logo from directory
	  $dbresult= mysqli_query(Connect(),"select `image`,`link1`,`link2`,`link3` from `mtbldownload` where id=".$post_id);
	  $filename_delete=mysqli_fetch_assoc($dbresult);
	  @unlink('../'.$filename_delete['image']);
	  @unlink('../'.$filename_delete['link1']);
	  @unlink('../'.$filename_delete['link2']);
	  @unlink('../'.$filename_delete['link3']);			
	  mysqli_query(Connect(),"delete from  mtbldownload  WHERE  id =".$post_id);
	}
	else if($typeback ==10)
	{  
	 //delete old logo from directory
	  $dbresult= mysqli_query(Connect(),"select `image`,movie from `mtblmovie` where id=".$post_id);
	  $filename_delete=mysqli_fetch_assoc($dbresult);
	  @unlink('../'.$filename_delete['image']);
	  @unlink('../'.$filename_delete['movie']);
				 mysqli_query(Connect(),"delete from  `mtblmovie`  WHERE  id =".$post_id);
	}
	
else if($typeback == 11)
{
    // دریافت نام تصویر از جدول
    $dbresult = mysqli_query(
        Connect(),
        "SELECT `image` FROM `mtblaudio` WHERE `id`=".$post_id
    );

    $filename_delete = mysqli_fetch_assoc($dbresult);

    // حذف تصویر از پوشه، در صورت وجود
    if ($filename_delete && !empty($filename_delete['image'])) {
        @unlink('../'.$filename_delete['image']);
    }

    // حذف رکورد از دیتابیس
    mysqli_query(
        Connect(),
        "DELETE FROM `mtblaudio` WHERE `id`=".$post_id
    );
}

    else if($typeback ==3)
	{  
      mysqli_query(Connect(),"delete from  mtblsubmenu WHERE  id =".$post_id);
	}
	else if($typeback ==6)
	{  
     	//delete old logo from directory
			$dbresult= mysqli_query(Connect(),"select `image` from `mtblslider` where id=".$post_id);
			$filename_delete=mysqli_fetch_assoc($dbresult);
			@unlink('../'.$filename_delete['image']);
						mysqli_query(Connect(),"delete from  mtblslider WHERE  id =".$post_id);
	}
    else if($typeback ==9)
	{  
	//delete old logo from directory
			$dbresult= mysqli_query(Connect(),"select `image` from `mtbladvertise` where id=".$post_id);
			$filename_delete=mysqli_fetch_assoc($dbresult);
			@unlink('../'.$filename_delete['image']);
						mysqli_query(Connect(),"delete from  mtbladvertise WHERE  id =".$post_id);
	}
	else if($typeback ==4)
	{  
			mysqli_query(Connect(),"delete from  mtbluser WHERE  id =".$post_id);
	}
	else if($typeback ==8)
	{  
		mysqli_query(Connect(),"delete from  mtblemaildl WHERE  id =".$post_id);
	}
	else if($typeback ==20)
	{  
	//delete message from inbox
		mysqli_query(Connect(),"delete from  mtblmessage WHERE  id =".$post_id);
		echo '  <script type="text/javascript" >
  window.location="adminmessages.php?type=1&msg=پیام مورد نظر حذف شد";
  </script>';
	}
	else if($typeback ==21)
	{  
	//delete message from senbox
		mysqli_query(Connect(),"delete from  mtblmessage WHERE  id =".$post_id);
		echo '  <script type="text/javascript" >
  window.location="adminmessages.php?type=2&msg=پیام مورد نظر حذف شد";
  </script>';
	}
	
	
}
else
{
	echo('
	<script type="text/javascript" >
window.location="../erorr404.php";
</script>');

	}
				

?>
  <script type="text/javascript" >
  window.location='index.php?type=<?php echo($typeback);  ?>&msg=رکورد مورد نظر حذف شد';
  </script>
</body>
</html>
<?php } ?>