<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>



<body>
<?php
if (isset($_POST['postid']))
{
$post_id=$_POST['postid'];
$typeback=$_POST['type_back'];
if(is_numeric($post_id)   && is_numeric($typeback))
{

              include('includes/function.php');
			  if ($_POST['selected']=="1")
						mysqli_query(Connect(),"UPDATE  mtbldownload SET  name =  'vizhe' WHERE  id =".$post_id);
			   else
						mysqli_query(Connect(),"UPDATE  mtbldownload SET  name =  '' WHERE  id =".$post_id);
						
}
else
{
  //header("Location: ../erorr404.php");
    ?>
              <script type="text/javascript" >
				window.location='../erorr 404.php';
			  </script>
          <?php
}
	
}
//header("Location: index.php?type=".$typeback."&msg=دانلود ویژه انتخاب شد");
?>
             <script type="text/javascript" >
				window.location='index.php?type=<?php echo $typeback ?>&msg=دانلود ویژه انتخاب شد';
			  </script>

</body>
</html>