<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
include_once('../jdf.php');
$shamsidate=jdate('Y/m/d');
$shamsitime=jdate('H:i:s');
if(isset($_POST['reciver']) || isset($_POST['msg']) )
{

	                include('includes/function.php');
if(!isset($_POST['msg']))
{
$sql = "INSERT INTO  `mtblmessage` (
`ID` ,
`Sender` ,
`Reciver` ,
`Title` ,
`Text` ,
`SendDate` ,
`SendTime` ,
`Readed`
)
VALUES (
NULL ,  '0',  '".$_POST['reciver']."',  '".$_POST['titr']."',  '".$_POST['message']."',  '".$shamsidate."',  '".$shamsitime."',  '0'
);";
 mysqli_query(Connect(),$sql);
}
else
{
			 $dbResult = mysqli_query(Connect(),"SELECT id FROM mtbluser where confirm=1 and enabled=1 ");
				while($post = mysqli_fetch_assoc ($dbResult) )
				{
					$sql = "INSERT INTO  `mtblmessage` (
`ID` ,
`Sender` ,
`Reciver` ,
`Title` ,
`Text` ,
`SendDate` ,
`SendTime` ,
`Readed`
)
VALUES (
NULL ,  '0',  '".$post['id']."',  '".$_POST['titr']."',  '".$_POST['message']."',  '".$shamsidate."',  '".$shamsitime."',  '0'
);";
 mysqli_query(Connect(),$sql);
				}	
}
						 ?>
						<script type="text/javascript" >
  window.location='index.php?type=0&msg=پیام شما ارسال شد';
  </script>		 
  <?php
}
else
{
							 ?>
  <script type="text/javascript" >
  window.location='index.php?type=0&msg=خطا';
  </script>		 
  <?php

}
?>
</body>
</html>