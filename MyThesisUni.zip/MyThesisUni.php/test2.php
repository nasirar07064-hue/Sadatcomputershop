<?php
if(isset($_POST['Warehouse_name2']) && isset($_POST['Goods_name3']) && isset($_POST['count'])){
$Wname2 = $_POST['Warehouse_name2'];
$Gname3 = $_POST['Goods_name3'];
$count = $_POST['count']; 
echo 1;
$sql1 = "INSERT INTO presentation (id_Warehouse, id_Goods, count)  VALUES ( $Wname2 ,  $Gname3 ,  $count )";
var_dump($conn->query($sql1)); 
if ($conn->query($sql1) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql1 . "<br>" . $conn->error;
}  
$conn->close();
}
?>

</form>
    </div>
      </div>  
        <br><br><br>  
      <div class="container" >
        <form action="" method="post">
            <div class="form-control">
            <select name="Warehouse_name2" id="Warehouse_name2">

<option value="1">1</option>

            </select>
            <label for='Warehouse_name2'>:نام گدام</label>      
            </div><br>
            <div class="form-control">
            <select name="Goods_name3" id="Goods_name3">

<option value="2">2</option>

            </select>
            <label for='Goods_name3'>: نام کالا</label>       
            </div><br>
            <div class="form-control">
      <input type="number" id="count" name="count"  autocomplete="off">
            <label for='count'>: تعداد کالا</label>                
            </div><br>          
            <div class="form-control">
            <input type="submit" value="افزودن کالا به گدام">
            </div>
        </form>```این قسمته فرمممه