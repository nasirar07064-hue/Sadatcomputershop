<?php require_once('config.php');?>
<?php
function Select($table,$wherefiled='',$wherevalue='',$and='',$or='',$order='',$sort='',$start='',$max='',$rand='',$like='')
{

	if($order!='' && $sort!='')
	$ord = " ORDER BY `".$order."` ".$sort;
	else $ord = $sort ='';
	if($wherefiled!='' && $wherevalue!='' && $like=='')
	$where = " WHERE `".$wherefiled."` = ".$wherevalue;
	elseif($wherefiled!='' && $wherevalue!='' && $like=='1'){
	$keyword = "'%".$wherevalue."%'";
	$where = " WHERE `".$wherefiled."` LIKE ".$keyword;
	}
	else $where ='';
	if($start !='' && $max != '')
	$limit = " LIMIT ".$start.",".$max;
	elseif($start !='' && $max=='')
	$limit = " LIMIT ".$start;
	elseif($rand=='1')
	$limit = " ORDER BY RAND() LIMIT 10 ";
	else $limit = '';
	$query = "SELECT * FROM `".$table."` ".$where.$and.$or.$ord.$limit;
	//die($query);
	$result = mysqli_query(Connect(),$query);
	if($result)
	return $result;
	else die('Invalid Query : ' . $query . mysqli_error(Connect()));
}

function Update($table,$up,$wherefield='',$wherevalue='')
{
	$wherevalue = trim(trim($wherevalue));
	if($wherefield!='' && $wherevalue!='')
	$where = " WHERE `".$wherefield."` = '".$wherevalue."' ";
	else $where ='';
	$query = "UPDATE `".$table."` SET ".$up. $where;
	//die($query);
	
	$result = mysqli_query(Connect(),$query);
	if($result)
	return $result;
	else die('Invalid Query : ' . $query . mysqli_error(Connect()));
}

function Insert($table,$fields,$value)
{

	$value = trim(trim($value));
	$query = " INSERT INTO `".$table."` (".$fields.") VALUES (".$value.") ";
	$result = mysqli_query(Connect(),$query);
	if($result)
	return $result;
	else die('Invalid Query : ' . $query . mysqli_error(Connect()));
}

function Del($table,$wherefield,$wherevalue)
{
	
	$query = " DELETE FROM `".$table."` WHERE `".$wherefield."` = ".$wherevalue;
	$result = mysqli_query(Connect(),$query) or die(mysqli_error(Connect()));
	if($result)
	return true;

}

function DelFile($dir,$file)
{
	$result = unlink($dir.$file);
	if($result)
	return true;
}

function LoginUser($user,$pass)
{
	Connect();
	$query = "SELECT * FROM `admin` WHERE `username` = '".$user."' AND `password` = '".$pass."' ";
	$result = mysqli_query(Connect(),$query);
	$row = mysqli_fetch_assoc($result);
	$total = @mysqli_num_rows($result);
	if($total)
	{
		$_SESSION['admin'] =  $row['username'];
		return true;
	}
}

function Upload($file,$tmp,$dir,$size,$ex,$width='500',$height='500',$url='')
{
	$msg=array();
	$rnd = uniqid();
	$file = str_replace(' ','-',trim($file));
	list($w,$h) = @getimagesize($tmp);
	$allowed_filetypes = explode(',',$ex);
    $max_filesize = $size;
    $ext = substr($file, strpos($file,'.'), strlen($file)-1);
	
		if(!in_array($ext,$allowed_filetypes))
		{
		  	$msg['error']= '<p class="text-danger">پسوند فایل مجاز نمی باشد</p>';
		  	return $msg;
		}
		if(filesize($tmp) > $size )
		{
		  $msg['error']= '<p class="text-danger">حجم عکس مناسب نمی باشد</p>';
		  return $msg;
		}
		 if($w > $width || $h > $height )
		{
		  $msg['error']= '<p class="text-danger">سایز عکس مناسب نمی باشد</p>';
		  return $msg;
		}
			if(move_uploaded_file($tmp,$dir.$rnd.$file)){
				$msg['success']=$rnd.$file;
				return $msg;
			}
			return false;
}
?>