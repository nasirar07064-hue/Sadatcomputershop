            <?php
			//var_dump(Connect());
			//die;
			?>
			<!-- start sidebar -->
			<div id="sidebar">
            
            <form action="posts.php" method="get">
            <input type="text" name="search" class="side_serach" placeholder="جستجو در سایت ..."  />
            </form>
             <div class="box-sidebar">
            <h6 class="sourcecode">کاربران</h6>
            <?php
			if(isset( $_GET['loginmsg']))
			 echo '<div id="messagebox22" class="messagebox22"><p onclick="closemsg();">×</p> '.$_GET['loginmsg'].'</div>';
			
			if(isset( $_SESSION['userlogin']))
			{
			 echo '<br/><div id="loginmsg" style=" font-size:18px; text-align:center;">'. $_SESSION['name'].'  خوش آمدی</div><br/>';			
             echo '<a style="font-weight:bold;color:red; font-size:16px; text-decoration:none;" href="logout.php"  >خروج</a>';
			}
			else
			{
			?>
             
<form id="formlogin" action="checkuser.php" class="sendcomment" name="form1" method="post"  >
<table  border="0" >
    <tr>
    <td>نام کاربری:</td>
    <td> <input type="text" name="username" id="username" required  title="نام کاربری"></td>
  </tr>
   <tr>
    <td>رمز عبور:</td>
    <td> <input type="password" name="password" id="password" required  title="رمز عبور"></td>
  </tr>


<tr>
    <td> </td>
    <td><input type="submit" name="submit"  class="submit"   value="ورود" /></td>
  </tr>
  
</table>                                     
 </form>
<br />
            <br />      <br />      <br />      <br />      <br />  <br />
            <?php
			}
			?>
            </div>
             <div class="clear"></div>
            <div class="box-sidebar">
            <h6 class="sourcecode">دسته بندی کالاها</h6>
            <ul>  
                <?php    
                //$dbsubmenu = mysqli_query("select id,title from mtblsubmenu where parentid =3 and parent=0",$connect); 
				$dbsubmenu = SELECT('mtblsubmenu','parentid','3',' AND parent=0');
       			while($dbsubject = mysqli_fetch_assoc($dbsubmenu))
				{
					echo '<li class="sourcecodeli"><a href="posts.php?cat=3&subject='.$dbsubject['id'].'&title='.
						 str_replace(' ','-', $dbsubject['title']).'">'.$dbsubject['title'].'</a></li>';
			    }
				?>
 
            </ul>       
            </div>
             <div class="clear"></div>
             <div class="box-sidebar">
            <h6 class="sourcecode">کالاهای ویژه</h6>
            <ul>  
                <?php    
										$dbresult = mysqli_query(Connect(),"
 select id,titr,image,shorttext,writedate ,writetime,'2' as type_m,price  from mtbldownload where  published = 1 and name='vizhe' 
 order by writedate desc ,writetime desc ");
					while($post = mysqli_fetch_assoc ($dbresult) )
					{?>
					<li class="sourcecodeli"><a href="<?php echo 'download.php?id='.$post['id'].'&title='.
						 str_replace(' ','-', $post['titr']); ?>"><?php echo $post['titr']?></a></li>
			       <?php
                   }
				?>
 
            </ul>       
            </div>
             <div class="clear"></div>
                         <div class="box-sidebar">
            <h6 class="sourcecode">کالاهای پربازدید</h6>
            <ul>  
                <?php    
										$dbresult = mysqli_query(Connect(),"
 select id,titr,image,shorttext,writedate ,writetime,'2' as type_m,price  from mtbldownload where  published = 1  
 order by view desc limit 10 ");
					while($post = mysqli_fetch_assoc ($dbresult) )
					{?>
					<li class="sourcecodeli"><a href="<?php echo 'download.php?id='.$post['id'].'&title='.
						 str_replace(' ','-', $post['titr']); ?>"><?php echo $post['titr']?></a></li>
			       <?php
                   }
				?>
 
            </ul>        
            </div>
             <div class="clear"></div>
             
                          <div class="box-sidebar">
            <h6 class="sourcecode">تبلیغات</h6>
                <?php    
										$dbresult = mysqli_query(Connect(),"
 select id,titr,image,link  from mtbladvertise where  enabled = 1  
 order by id desc");
					while($post = mysqli_fetch_assoc ($dbresult) )
					{?>
					<a href="<?php echo $post['link'] ?>"><img src="<?php echo $post['image']?>" alt="<?php echo $post['titr']?>" width="100%" 
                     style="border-radius:15px;margin-bottom:5px;"/></a>
			       <?php
                   }
				?>

            </div>
             <div class="clear"></div>
          
          </div>
           <!-- ends sidebar -->
