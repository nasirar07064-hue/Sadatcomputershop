<?php
if(session_id() == '') {
    session_start();
}

function Connect(){
$connect = mysqli_connect('localhost' , 'root' , '' , 'computershop');
mysqli_set_charset($connect,"utf8");
return $connect;
}

function clean($str) {
$str = @trim($str);
$str =str_replace("'","",$str);
return $str;
}
?>