<?php
session_start();
session_destroy();
unset($_SESSION['logedin']);
unset($_SESSION['Logedin']);
unset($_SESSION['type']);
header('location:../index.php');
?>
