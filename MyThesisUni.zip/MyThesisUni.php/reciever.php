<?php 
function get($url,$api,$trans_id,$id_get){
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_POSTFIELDS,"api=$api&id_get=$id_get&trans_id=$trans_id");
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
$res = curl_exec($ch);
curl_close($ch);
return $res;

}
include('includes/function.php');
$url = 'http://payline.ir/payment/gateway-result-second';
$api = 'fc0c9-dfed0-2b21e7-4226f2-397df094041d72c46ad70972036f8';
$trans_id = $_POST['trans_id'];
$id_get = $_POST['id_get'];
$result = get($url,$api,$trans_id,$id_get);
echo '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />';
switch($result){
case '-1' :
echo 'api ارسالی با نوع api تعریف شده در payline سازگار نیست';
break;
case '-2' :
echo 'trans_id ارسال شده معتبر نمی باشد';
break;
case '-3' :
echo 'id_get .ارسالی معتبر نمی باشد';
break;
case '-4' :
echo ' .چنین تراکنشی در سیستم وجود ندارد و یا موفقیت آمیز نبوده است';
break;
case '1' :
echo '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />';
$t_id=0;
if(isset($_GET['t_id']) && is_numeric($_GET['t_id']))
{
	$t_id=$_GET['t_id'];
}
$sql = "UPDATE  `transactions` SET  
`id_get` =  ".$id_get.",
`trans_id` = ".$trans_id.",
`result` =1
 WHERE  id =".$t_id.";";
  mysqli_query($sql,$dlink);
    $dbresult = mysqli_query(Connect(),"select type  from `transactions` where id =".$t_id);
	  $trans = mysqli_fetch_assoc($dbresult);

	 if($trans['type']==2)
	  {
  	  $dbresult = mysqli_query(Connect(),"select down_id  from `transactions` where id =".$t_id);
	  $res = mysqli_fetch_assoc($dbresult);

?>
<style>
body{
	background-color:#fff;
	color:#FFF;
	font-family:Tahoma, Geneva, sans-serif;
	font-size:13px;
	}
	.panel1{
		width:50%;
		height:270px;
		background-color:#fff;
		border:2px solid #008000;
		border:5px solid 
		margin:100px ;
		margin-right:auto;
		margin-left:auto;
		padding:20px;
		text-align:center;
		}
		.panel1 .link{
		width:80%;
		height:50px;
		background-color:#008000;
		color:#FFF;
		margin:10px ;
		text-decoration:none;
		line-height:40px;
		margin-right:auto;
		margin-left:auto;
		padding:10px;
		}
		.panel1 .link:hover{
		background-color:#099;
		}
</style>
<div class="panel1">
<a href="download.php?id=<?php echo $res['down_id']; ?>&amp;t_id=<?php echo $t_id; ?>"><img src="images/tik.jpg" title="پرداخت با موفقیت انجام شد . برای دریافت فایل کلیک کنید" width="200" height="200"/></a><br />

<a class="link" href="download.php?id=<?php echo $res['down_id']; ?>&amp;t_id=<?php echo $t_id; ?>">پرداخت با موفقیت انجام شد . برای مشاهده لینک دانلود کلیک کنید</a>

</div>
<?php
	  }
break;
}
?>