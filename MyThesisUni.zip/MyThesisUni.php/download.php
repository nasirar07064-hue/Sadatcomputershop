 <?php include('includes/header.php'); ?>
    
		<!-- WRAPPER -->
		<div id="wrapper">
			

		<!-- MAIN -->
		<div id="main" >
			
			<!-- content -->
			<div id="content" >
				
				<!-- title -->
				<div id="page-title">
					<span class="title"></span>
					<span class="subtitle"></span>
				</div>
                
<?php

		if (isset($_GET['id']) && is_numeric($_GET['id']) )
		{
			mysqli_query(Connect(),"update mtbldownload set view=view+1 where id=".$_GET['id']);
              $dbresultpost = mysqli_query(Connect(),"select * from mtbldownload where  published = 1 and id=".$_GET['id']);
			  $post=mysqli_fetch_assoc($dbresultpost);
  ?>              
                
				<!-- ENDS title -->
				<h1 class="contenth1 sourcecodeli" style="background-color:#333"><?php echo $post['titr'];?></h1>
				<!-- Portfolio -->
 <?php
$pardakht=0;	 
	if(isset($_GET['t_id']) && is_numeric($_GET['t_id']))
	{
		
	  $dbresult = mysqli_query(Connect(),"select result  from `transactions` where id =".$_GET['t_id']." and result=1  
	  and down_id=".$_GET['id']."  and price>=".$post['price']);
	  $trans = mysqli_num_rows($dbresult);
	 if($trans>0)
	{
	  $pardakht=1;
	  echo   '<div class="message" style="width:90%;margin-right:30px;background-color:green;color:white;text-align:center">
						 پرداخت موفقانه انجام شد.حالا می توانید آن را از پاین صفحه دانلود کنید.
                        </div>';
	}
		
	} 
?>
                
				<div class="maintext">
                    <div class="shorttext"><?php echo $post['shorttext'];?></div>

                    <center><img class="mainimg" src="<?php echo $post['image'];?>" alt="<?php echo $post['titr'];?>" /></center>
                  <br/><br/>
                    <?php echo $post['longtext'];?>
                     <br/><br/>
                     
                     
 <?php  
    if ($post['price'] <=0 || $pardakht==1 )
	 {                   
      if ($post['link1'] <> "" || $post['link2'] <> "" || $post['link3'] <> "")
	  { 
		 echo('<div class="downloadpanel ">
		   <h3>  لینک های دانلود </h3>');
		   
		   if ($post['link1'] <> "")
		   echo ('
		   <a style="color:#fff;" href="'.$post['link1'].'">'.$post['linktitle1'].'</a>');
		   if ($post['linkpass1'] <> "")
		   echo ('    رمز فایل : '.$post['linkpass1']);
		   
		   echo '<br/><br/>';
		   
		    if ($post['link2'] <> "")
		   echo ('
		   <a style="color:#fff;" href="'.$post['link2'].'"> '.$post['linktitle2'].'</a>');
		   if ($post['linkpass2'] <> "")
		   echo ('    رمز فایل : '.$post['linkpass2']);
		   
		    echo '<br/><br/>';
		   
		  if ($post['link3'] <> "")
		   echo ('
		   <a  style="color:#fff;" href="'.$post['link3'].'">  '.$post['linktitle3'].'</a>');
		   if ($post['linkpass3'] <> "")
		   echo ('    رمز فایل : '.$post['linkpass3']);

		   echo ('</div> <br/><br/><br/><br/><br/><br/><br/><br/><br/>');     
	  }
	 }
 else if ($post['price'] >0 )
 {
		 		 echo('<div class="downloadpanel divbuy"><br/>');
	echo ('    قیمت این محصول: '.'<b style="color:#fff; font-size:20px;margin:10px;">'.$post['price'].'</b>'.' افغانی<br/>');
  
  ?>
<script type="text/javascript">
function show_buy_form() {
document.getElementById('buyform').style.display='block';
}
</script>
  <br/>
  <a   class="kharid" onClick="show_buy_form()" >  &nbsp;&nbsp;خرید جنس از طریق پرداخت اینترنتی</a><br/><br/> 


<div id="buyform" hidden="hidden">
 <form action="sender.php" method="post">
  <input type="text" name="u_name" id="u_name" placeholder="نام" />
  <input type="text" name="u_email" id="u_email" placeholder="ایمیل" />
  <input type="text" name="u_tell" id="u_tell" placeholder="تلفن"/>
  <input type="text" name="u_address" id="u_address" placeholder="آدرس"/>
  <input type="submit" name="submit" id="submit" value="پرداخت"/>
   <input type="hidden" name="post_id" id="post_id" value="<?php echo $post['id']; ?>"/>
   <input type="hidden" name="type" id="type" value="2"/>
   <input type="hidden" name="amount" id="amount" value="<?php echo $post['price']; ?>"/>
    
 </form>
</div> 

<ul style="list-style:circle">
<li>  پرداخت از طریق درگاه پی لاین انجام خواهد شد .</li>
<li>  پس از پرداخت مبلغ به این صفحه ارجاع داده می شوید و میتوانید فایل مورد نظر را  با لینک مستقیم دانلود کنید.</li>
</ul>

<br>
  <?php
  
   echo ('</div> <br/><br/><br/><br/><br/><br/><br/><br/><br/>');    
	  }
?>
                     
                     
				</div>
				

				<!-- pagination -->	
				<div class="clear"></div>
                

		
<?PHP
		}
		else 	
		{
			
echo 'موستفانه مطلب مورد نظر شما پیدا نشد';
		}
?>



					

<?php   
		if (isset($_GET['id']) && is_numeric($_GET['id']) )
		{
              $dbresultcomment = mysqli_query(Connect(),"select * from mtblcomment where  readed = 1 and pagename='download.php' and postid=".$_GET['id'] );
			  $countcomment=mysqli_num_rows( $dbresultcomment );
?>
					<!-- Comments-Block -->
					<div id="comments-block">
						<div class="n-comments"><?php echo $countcomment; ?></div> <div class="n-comments-text">نظرات</div>
						<!-- comments list -->
						<ul class="commentlist">

<?php
			  while($comment=mysqli_fetch_assoc($dbresultcomment))
			  {
?>
							<li class="comment" id="comment-18">
								<div id="div-comment-18" class="comment-body">
									<div class="comment-author vcard">
										<img alt='' src='img/avatar.png' class='avatar avatar-60 photo' height='70' width='60' />
										<span class="says"><?php echo $comment['name']; ?>:</span>
									</div>
					
									<div class="comment-meta">
										 <?php echo $comment['date_time']; ?>
									</div>
					
									<p class="maincoment"><?php echo $comment['comment']; ?></p>
					
									<div class="reply">
										<a class='comment-reply-link' href="#">پاسخ</a>
									</div>
								</div>
							</li>
 <?php
			  }
		}
?>
                    <br/><br/><br/>     
                            
						</ul>
						<!-- ENDS comments list -->
		
					</div>
					<!-- ENDS Comments-block -->	
		

								<h3 style="margin-right:10px">نظر خود را ارسال کنید</h3>	
								<!-- form -->
<br/>
 <div id="ajaxloader"> </div>
   <br/>                       
<form id="form1" class="sendcomment" name="form1" method="post"  >
<table  border="0" >
  <tr>
    <td>نام:</td>
    <td> <input type="text" name="name" id="name" required  title=" نام و نام خانوادگی"></td>
  </tr>
  <tr>
    <td>ایمیل:</td>
    <td> <input  style="direction:ltr" type="email" name="email" id="email"  required="required" title=" ایمیل به طور صحیح وارد شود" /></td>
  </tr>
  <tr>
    <td valign="middle">دیدگاه: </td>
    <td><textarea name="comment" id="comment" required cols="60" rows="5"></textarea></td>
  </tr>
  <tr>
    <td> </td>
    <td><img src="captchaphp/calledcaptcha.php"  width="90" height="30" style="border-radius:2px;"/> </td>
  </tr>
    <tr>
        <td>کد امنیتی :</td>
        <td><input   type="text" name="capcode" id="capcode"   required="required" /></td>
    </tr>
 
<tr>
    <td> </td>
    <td><input type="button" name="submit"  class="submit"  onClick="formget(this.form, 'savecomment.php');" value="ارسال نظر" /></td>
  </tr>
  
</table>                                     
        <input type="hidden" name="postid" id="postid" value="<?php echo $_GET['id'] ?>"/>
        <input type="hidden" name="pagename" id="pagename" value="<?php echo basename($_SERVER['PHP_SELF']); ?>"/>
 </form>
								<!-- ENDS form -->
<br/>
<br/>



			</div>
			<!-- ENDS content -->
            
            <!-- start sidebar -->
<?php include('includes/sidebar.php'); ?>

			
		
			<!-- FOOTER -->
	<?php include('includes/footer.php'); ?>