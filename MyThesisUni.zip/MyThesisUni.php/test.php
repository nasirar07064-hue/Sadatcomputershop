<?php
$blacklist = array('خر','گاو');
function check($str,$blacklist) {
    foreach ($blacklist as $word) {
        if (strpos($str, $word) !== FALSE) {
            return true;
        }
    }
    return false;
}

if(isset($_POST['submit'])){
  $lx=trim($_POST['Text']);
    if(check($lx,$blacklist)) { 
	echo 'محتوای شما مشکل اخلاقی دارد';
    }
    else{
    echo 'چه انسانی باادبی هستی';
    }
}
?>
<html>
<form action="" method="Post">
  
  <input type="text" name="Text" id=""  />
  <button type="submit" name="submit">sub</button>
</form>

<br>

</html>